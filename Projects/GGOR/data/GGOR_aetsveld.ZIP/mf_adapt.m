% Dutch top system consisting of a shallow Holocene aquifer underlain by a
% semi-pervious layer on top of a larger regional aquifer. The shallow
% aquiifer is intersected by may dithces in which the surface water level
% is maintained to manage the groundwater system.
% We simulate two parallel ditches in this shallow top system underlain by
% the confining bed and the regional system. THe ditches may cut through
% the confining layer.
% Input is recharge and seepage from below through the confining bed from
% the regional aquifer. Extraction is evapotranspiration and leakage to the
% ditches. These dithches may at times also infiltrate.
% The specific yield will be made dependent on the the water table
% elevation in the shallow aquifer.
% When this water table intersects ground surface, surface runoff occurs.
% There is no limit to the infiltration capacity of the soil.
% Evapotranspiration maybe made depdendent on the extincktion depth.
% We may apply various tricks to influence the behavior of the boundary
% conditions such as more than one drainage level wiithin a single cell.
% The smallest conceivable model consists of only a single cell.
% It is sufficient to simuulate only half the strip of land between the
% ditch and its axis of symmetry at the center.
%
%
% TO 100905 101020
%
% Copyright 2009 2010 Theo Olsthoorn, TU-Delft and Waternet, without any warranty
% under free software foundation GNU license version 3 or later

% JB 22082011
% regel 118 aanpassing Cin en Cex voor combinatie riv+drn in ditch.
% controle van deze nieuwe mfadapt met oudere versie geeft verschillende
% uitkomsten. De verschillen komen door verandering definitie weerstand deklaag 
% onder de sloot. Laten controleren door Theo.

clear variables; close all;

tstart=tic;  % overall time
basename='GGOR_Aetsveld';  % Data for HoekerGarsten polder, near Utrecht Nettherlands

%% Constants
drnfactor  = 2; %=verhoudig infiltratie/drainage weerstand in sloot. 
                % In regionaal model HMP/Noorderpark toegepast: 5, 
                % echter voor lokaal perceelmodel is eerder 2 te verwachten.
trenchdepth= 0.3; %diepte van de greppels in de percelen
maxdraindistance= 40; % maximale sloot of greppelafstand om te grote percelen op te delen 
dx        = 1;  % cell width choice
APRIL     = 4;
SEPTEMBER = 9;

cDRAIN_DEFAULT=0.1; % default resistance drains on ground surface
iDRN    =7;    % zone of drains (simulate surface runoff)
iTRENCH= 6;    % zone of trenches between ditches
iDITCH1 =1;    % ditch in layer 1
iDITCH2 =3;    % ditch in layer 2
iWVP2   =4;    % zone of regional aquifer



%% Read meteo time series

fid=fopen('PE-00-08.txt','r');
A=fscanf(fid,'%d-%d-%d %f %f',[5,Inf])';
fclose(fid);

tne=[datenum(A(:,3),A(:,2),A(:,1)) A(:,[4 5])/1000]; % [t P N] % to mm/d

fprintf('Length of time series = %d\n',length(tne(:,1)));
%plot(tne(:,1),tne(:,2),'b',tne(:,1),tne(:,3),'r');

[YR,MONTH]=datevec(tne(:,1)');

clear A;

%% mf2k has 1000 stress period limit, use mf2005 instead, see nam sheet

RECH=ones(1,1,length(tne(:,1))); RECH(1,1,:)=tne(:,2)-tne(:,3);
%EVTR=ones(1,1,length(tne(:,1))); EVTR(1,1,:)=tne(:,3);

%% Get data from GGOR basis data spreadsheet (should be database)

tic
fprintf('\nReading in the spatial database <<%s>>, may require some patience. Please wait ...',[basename '.dbf']);

data=dbfread(basename);
%parnams={data.fieldname};
for i=1:length(data), data(i).fieldname=deblank(data(i).fieldname); end %toegevoegd josbe 17043013
fprintf('\nPfff .. Done, took me %.2f seconds.\n',toc);
    
%% aliases .. replace column names

fprintf('Turning database inside out to get a record per section, please wait ...\n');
tic;
aliases= {
    'CDEK_new'  'C_DEK';
    %'DIKTE_DEK'  'DDEK';
    'AHN_MED2'  'AHN';
    'ZP_ACT'      'ZP';
    'WP_ACT'      'WP';
    'KWELGEMR_2'    'q';
    'Kh'           'hk1';  
    'MU_2'        'MU';
  %  'WCOEFDEK'    'WCOEF';
    };


% for i=1:size(aliases,1), data(strmatchi(aliases{i,1},{data.fieldname},'exact')).fieldname=aliases{i,2}; end
% 
% NRec=length(data(1).values);
    for i=1:size(aliases,1),
        j=strmatchi(aliases{i,1},{data.fieldname},'exact');
        if j>0
            data(j).fieldname=aliases{i,2};
        else
            fprintf('Can''t %s in fieldnames\n',aliases{i,1}); 
        end
    end

    NRec=length(data(1).values);
    
P(NRec).FID2=NaN;  % memory allocation

for ifld=1:length(data)
    fldnm=data(ifld).fieldname;
  %  if data(ifld).fieldtype=='N' % Josbe: waarom moet het type 'N' zijn?
        for iRec=1:NRec
            P(iRec).(fldnm)=data(ifld).values(iRec);
        end
    end
%end

%% Adaptations of and additions to the databasse + constants (defaults)

C_DEK_MIN=1;       % default minimum resistance cover layer 

for i=1:length(P)
    P(i).GP= (P(i).ZP+P(i).WP)/2;
    P(i).C  = max(C_DEK_MIN,P(i).C_DEK);
 
    P(i).wd    = 2;           % [ m ] default width of ditch 
    % cexditch=0.0005 en cin=0.001 moet dezelfde uitkomsten geven als de
    % oudere versie van mf-adapt met een GHB boundary tpv de ditch,
    % vooralsnog zijn de uitkomsten verschillend
    P(i).cexditch   =2;% 0.0005 ;%2;         % theo=0.05 [ d ] exfiltration resistance of ditch (combi cex_drn+cex_riv)
    P(i).cin   = drnfactor*P(i).cexditch; % theo=0.25 [ d ]infiltration resistance of ditch (=cin_riv)
    P(i).cex   =1/(1/P(i).cexditch-1/P(i).cin); % exfiltration resistance of drn % toegevoegd JosBe
    P(i).dd    = 0.6;         % [ m ] default ditch depth
 
  
  % P(i).L   = P(i).L/(P(i).sloten+1); % correctie voor percelen met tussensloten: tussensloten moeten handmatig in de database worden gebracht op basis van luchtfoto's of GBKN)
   P(i).w   = P(i).L/2;        % [m] half parcel size between water divide and center of ditch
%% Onderstaande regels opnemen voor GHG en GVG om greppels/sloten in werking te stellen; 
    if  P(i).w >maxdraindistance/2
         P(i).w =maxdraindistance/2;  % halve percelen breder dan maxdraindistance ofwel percelen breder dan 2x maxdraindistance hebben tussenliggende greppels. 
         %Vooralsnog rekenen we de greppels als sloten door: in het
         %veenweidegebied met een geringe drooglegging is deze
         %vereenvoudiging vermoedelijk niet ver naast de waarheid: op termijn moeten
         %greppels afzonderlijk ingebouwd worden
    end
%% onderstaand blok is een alternatieve manier om slootafstand te verminderen
nn=1;
while P(i).L/nn>maxdraindistance % maximale greppel of slootafstand
      nn=nn+1;
end
    P(i).greppelafstand = P(i).L/nn;        
    P(i).greppels=nn-1; % aantal greppels
    P(i).activecells=round(P(i).L/2/dx);
    P(i).greppelcells=round((P(i).activecells-1)/nn); %aantal cellen tussen greppels
%     P(i).w   = P(i).greppelafstand % deze regel dient om greppels als sloten te beschouwen, greppels moeten dan uitgezet
%%
P(i).D1 = max(0.1,P(i).DDEK); % [m] thickness of top layer
    P(i).D2 = 30;                 % [m] default D of regional aquifer
 
    P(i).z1 = P(i).AHN-P(i).D1; % bottom of top aquifer elevation
    P(i).z2 = P(i).z1 -P(i).D2; % bottom of bot aquifer elevation
    
%     % set GXGDBF in database from ground surface to NAP datum
%     P(i).GHGDBF   = P(i).GHGDBF+P(i).AHN; % [NAP] GGG from databse (model Ouboter)
%     P(i).GLGDBF   = P(i).GLGDBF+P(i).AHN; % [NAP] GLG from databse (model Ouboter)
%     P(i).GVGDBF   = P(i).GVGDBF+P(i).AHN; % [NAP] GVG from databse (model Ouboter)
      
    % Hydraulic parameters, conductivities of the phreatic and second aquifer

    %    hk1 from database, see aliases
    %% MANIPULATIE VAN DE INVOER
%    P(i).q      = P(i).q; % bij doorsnijdende sloten treden fluxen m.n. op in sloten 
    P(i).D_sdl1=P(i).DDEK-P(i).D_wvp1;
   P(i).KD1=P(i).D_sdl1*P(i).hk1+P(i).D_wvp1*1; %Formatie van Echteld bevat zandlagen, in Vechtbaggeren met k=0.25
    % in de doorlatendheid van de deklaag zijn zandlagen van Echteld met k=... verwerkt.
    P(i).hk1      =P(i).KD1/P(i).D1; 
  %  P(i).hk1      = 1*P(i).hk1; % doorlatendheid deklaag HMP x factor
    P(i).hk2      = 30;       % [m/d] default k of regional aquifer

  %  P(i).vk1      = P(i).D1/P(i).C; % vert conductivity first layer, requires layvka to be 0 in the LAY worksheet
    P(i).vk1      = P(i).DDEK/P(i).C; % vert conductivity first layer, requires layvka to be 0 in the LAY worksheet
 
    P(i).vk2      = 0.2 * P(i).hk2;       % default vertical cond regional aquifer, , requires layvka to be 0 in the LAY worksheet
 %   P(i).vk2      = 0.2 * P(i).hk2;       % default vertical cond regional aquifer, require layvka=0 in the LAY worksheet
   
%    if P(i).grondsoort==4 %grondsoort 4 is lichte zavel, grondsoort 3 is klei en grondsoort 6 is veen. 
%        % Op de nieuwe veenbodemkaart van Utrecht komt in de HoekerGarsten polder geen veen meer voor. Op deze
%        % plaats wordt nu zware klei aangegeven
    P(i).S1       = 1*P(i).MU ;         % [ - ] Storage coefficients deklaag HMP x factor
%    P(i).S1       = 0.3 ;         % [ - ] Storage coefficient layer 1
 %   P(i).hk1      = 0.5; % 0.5;   % k of layer 1
%    else 
%       P(i).S1       = 0.3;         % [ - ] Storage coefficient layer 1
%        P(i).hk1      =0.3;        % k of layer 1
%    end
    %P(i).S1       = 1e-4 ;         % [ - ] Storage coefficient layer 1
    P(i).S2       = 1e-5* P(i).D2; % [ - ] Storage coefficient layer 2
    
    P(i).zdr   = P(i).AHN;     % [NAP] default drain elevation (Ground surface)
    
    % optie: Niet-stationaire modeldatabase per maand flux uitlezen.
    % kunnen we rechtstreeks uit een database Cell/Knoop vs tijd lezen
    % voor elke afzonderlijke cell
    
end

fprintf('Took %.3f seconds.\n',toc);

tic
fprintf('Ready to go ...\n');

%% Use only these cross sections/parcels

%P=P(1276:1277); %1277=31H0870-1
P=P([P.WP]<0);
 P=P([P.grondsoort]>1);
 P=P([P.grondsoort]~= 5);
P=P([P.MU]>0);
P=P([P.hk1]>0);
P=P([P.L]>0);
P=P([P.q]<=1);
P=P([P.q]>=-1);
%P=P(1:2);
%P=P(1501:end);

%% Cleanup free memory

%save P; % need this for model testing in testmdl.m

clear data; 

%% Model grid


xGr=[P(1).wd/2 0:dx:max([P.w])+P(1).wd/2]; % [m] width of model (max length of any parcel)
yGr=0:1:length(P);                % each XC-section gets its own row (CHANI=0)
zGr=[0;-1;-2];                    % default zGr values, will be adjusted to actual parcel
[xGr,yGr,xm,ym,Dx,Dy,Nx,Ny]=modelsize(xGr,yGr);

Z=NaN(Ny,Nx,length(zGr));
for iy=1:length(P)
    Z(iy,:,1)=P(iy).AHN;
    Z(iy,:,2)=P(iy).z1;
    Z(iy,:,3)=P(iy).z2;
end

DZ=abs(diff(Z,1,3)); Nz=size(DZ,3);  % -1 because of 1 confining bed

% full 3D DX, DY can't use meshgrid with three args because DZ not uniform
[DX,DY]=meshgrid(Dx,Dy); DX=repmat(DX,[1,1,Nz]); DY=repmat(DY,[1,1,Nz]);

%% Build IBOUND use zone number to identify zones

IBOUND=ones(Ny,Nx,Nz);

for iy=1:length(P),
    % aquifer 1
    IBOUND(iy,:,1)           =iDRN;    % location of drain on surface
%     for mm=1 : P(iy).greppels                     % activeer greppels
%     IBOUND(iy,mm*P(iy).greppelcells,1)=iTRENCH;   % activeer greppels
%     end                                           % activeer greppels
    IBOUND(iy,xm>P(iy).w   ,1)=0;       % inactive cells
    IBOUND(iy,xm<P(iy).wd/2,1)=iDITCH1; % location of ditch
    
    % aquifer 2
    IBOUND(iy,:,2)           =iWVP2;   % second aquifer
    IBOUND(iy,xm>P(iy).w   ,2)=0;       % inactive cells
    IBOUND(iy,xm<P(iy).wd/2,2)=iDITCH2; % location of ditch
end

IB1=IBOUND(:,:,1); % useful later on
IB2=IBOUND(:,:,2); % useful later on
IBOUND_lay1=IBOUND(:,:,1); % IBOUND for only layer 1, useful later on
IBOUND_lay2=IBOUND(:,:,2); % IBOUND for only layer 2, useful later on


%% Build model arrays

HK    =ones(size(IBOUND));
VK    =ones(size(IBOUND)); % use vertical conductivity not anisotropy
VKCB  =ones(size(IBOUND));
SY    =ones(size(IBOUND));
SS    =ones(size(IBOUND));
STRTHD=ones(size(IBOUND));

HK(:,:,1)   =[P.hk1]' * ones(size(xm));  % kh of top aquifer
HK(:,:,2)   =[P.hk2]' * ones(size(xm));  % kh of bottom aquifer
VK(:,:,1)   =[P.vk1]' * ones(size(xm)); % kz of top aquifer
VK(:,:,2)   =[P.vk2]' * ones(size(xm)); % kz of bottom aquifer

%% Elastic storage coefficients are used instead of specific storage coefficients.
%  Therefore, STORAGECOEFFICIENT must be on and MF2005 must be
%  used (see worksheet MFLOW)
SY(:,:,1)   =[P.MU]' * ones(size(xm));
SS(:,:,1)   =[P.S1]' * ones(size(xm));
SY(:,:,2)   =[P.MU]' * ones(size(xm));
SS(:,:,2)   =[P.S2]' * ones(size(xm));

%% Start head

STRTHD(:,:,1)=[P.GP  ]'*ones(size(xm));  % start head of top aquifer
STRTHD(:,:,2)=[P.GP  ]'*ones(size(xm));  % start head of bottom aquifer

%% Replace the top of the cover layer at the ditch by the bottm of the ditch

IDitch=find(IB1==iDITCH1);

ZDitchBot=([P.GP]'-[P.dd]')*ones(size(Dx)); % ditch bottom elevation
Z1=Z(:,:,1);                  % copy first layer for manipulation
Z1(IDitch)=ZDitchBot(IDitch); % replace Z(:,:,1) at ditch by ditch bottom
Z(:,:,1)=Z1;                  % new Z(::,1) now with ditch bottoms at ditch

Delta = Z(:,:,1)-Z(:,:,2); % dikteverschil tussen onderkant laag1 en onderkant laag 2
Delta1 =Delta;

for iy=1:length(P)
    % aquifer 1
    if Delta1(iy,1) <=0 
        Delta(iy,1) =0.001;
    end % minimale dikte laag 1 onder ditch handhaven, anders vallen hier cellen droog
    if Delta1(iy,1)  >0 
        Delta(iy,1) =0;
    end    %   
    Delta(iy,2:end)=0;
end
 
Z(:,:,2)=min(Z(:,:,[1 2]),[],3)-Delta;    % Deze regel lijkt niet logisch, vermoedelijk niet af Theo!! --Delta is door JB toegevoegd-- lower top of second aquifer as needed

ZDitch=Z1(IDitch);
%% Drains at ground surface to compute surface runoff

IDRN=find(IB1==iDRN);
CDRN=(Dy*Dx)./cDRAIN_DEFAULT;  % compute drain conductance
CDRN=CDRN(IDRN);

hDRN=[P.AHN]'*ones(size(Dx));  % [Ny*Nx] drain head is equal to AHN, ground surface

hDRN=hDRN(IDRN);

%% Trenches to compute TRENCH runoff (greppelafvoer)
% 
% ITRENCH=find(IB1==iTRENCH);
% CDRN=(Dy*Dx)./cDRAIN_DEFAULT;  % compute drain conductance
% CDRN=CDRN(IDRN);
% 
% hTRENCH=([P.AHN]'-0.2)*ones(size(Dx));  % [Ny*Nx] drain head is equal to AHN-0.2 m, trench depth
% if [P.AHN]-0.2<[P.ZP]
%     then hTRENCH=[P.ZP]*ones(size(Dx);
% end
% hTRENCH=hTRENCH(ITRENCH); % voeg de trenches samen met de maaiveldafvoer.
% %% Trenches to compute TRENCH runoff (greppelafvoer)
% 
% ITRENCH=find(IB1==iTRENCH);
% CTRENCH=(Dy*Dx)./cDRAIN_DEFAULT;  % compute drain conductance
% CTRENCH=CTRENCH(ITRENCH);
% 
% hTRENCH=([P.AHN]'-trenchdepth)*ones(size(Dx));  % [Ny*Nx] drain head is equal to AHN-depth of trench (m)
% if ([P.AHN]'-trenchdepth)<[P.ZP]'
%    hTRENCH=[P.ZP]'*ones(size(Dx));
% end
% hTRENCH=hTRENCH(ITRENCH);

%% Handling infiltration and exfiltration for the ditch.
%  Use RIV and DRN in parallel to obtain a higher entry resistance than
%  exit resistance.

% find the right most cell of the ditch in every cross section, that is
% where the vertical face of the ditch is in

IB=[IB1 IB1(:,end)]; % top of IBOUND, expanded because we will differentiate next
IB(IB~=iDITCH1)=iDRN;     % make sure we only have iDITCH1 and iDRN in IB
IB=diff(IB,1,2);          % find ditch-face locations be differentiating with respect to x

Omega = Dy*Dx +...        % cell area
       (Dy.*[P.dd]')*ones(size(Dx)).*(IB~=0);   % vertical face of ditch

% Conductances
CEX=Omega./([P.cex]'*ones(size(Dx))); % exfiltration to be handled by drn + riv
CIN=Omega./([P.cin]'*ones(size(Dx))); % infiltration to be handled by riv alone

% Now only keep the cells that really are dithc cells
CEX =CEX( IDitch); % to be handled by RIV+DRN
CIN =CIN( IDitch); % to be handles by RIV

%% Resistance due to partial penetration of ditch into 2nd layer
%  Assuming the ditch bottom is flat at top of second layer.

w2   = 0.5*DZ(:,:,end)./VK(:,:,end);  % Vertical resistance of lower layer (half thickness)

% resistance due to partial penetration in second aquifer
w2pp = 2./(pi*sqrt([P.hk2]'.*[P.vk2]')).*log(4*([P.D2]'./(pi*[P.wd]')).*([P.hk2]'./[P.vk2]'));
w2pp = w2pp*ones(size(Dx));
w2pp(IB2~=iDITCH2)=0;

VK(:,:,end)=0.5*DZ(:,:,end)./(w2+w2pp); % pp resistance now included in vertical conductivity
% of the cells below the ditch in layer 2.

%% Upward seepage (positive) will be divided across the cells of layer (aquifer) 2

QSeep = (Dy*Dx).*([P.q]'*ones(size(Dx)));
ISeep = find(IB2==iWVP2 | IB2==iDITCH2);
QSeep=QSeep(ISeep); % only keep the cells that are in the second aquifer
ISeep=ISeep+Ny*Nx;  % shift index of cells to 2n aquifer

%% using the global indices compute the Layer Row Column indices necesary
%  to specify the boundary conditions in MODFLOE throuth the DRN, GHB and
%  WEL packages

LRC_drn  =cellIndices(IDRN,  size(IBOUND),'LRC'); % for surface runoff
%LRC_trench=cellIndices(ITRENCH,  size(IBOUND),'LRC'); % for trench runoff
LRC_ditch=cellIndices(IDitch,size(IBOUND),'LRC'); % for ditches
LRC_seep =cellIndices(ISeep, size(IBOUND),'LRC'); % for seepage

uDRN   =ones(size(IDRN));   % a column of ones for easyier multiplying below
uDitch =ones(size(IDitch)); % drainage 
%uTrench  =ones(size(ITRENCH)); %trenches
uSeep  =ones(size(ISeep));

%% We need NPER so get pervals from xls file

[pernams,pervals]=getPeriods(basename);
NPER=size(pervals,1); % number of stress periods defined in worksheet PER

%% specify the arrays for the boundary conditions

for iPer=1:NPER

    if MONTH(iPer)>=APRIL && MONTH(iPer)<=SEPTEMBER, h_ditch=[P.ZP]'; else h_ditch=[P.WP]'; end
    h_ditch=h_ditch*ones(size(Dx));
    h_ditch=h_ditch(IDitch);
              
    if iPer==1;
        DRN=[iPer*uDRN   LRC_drn          hDRN    CDRN;  % surface runoff
         %    iPer*uTrench LRC_trench      hTRENCH CTRENCH;  % trench runoff
             iPer*uDitch LRC_ditch h_ditch CEX];  % ditch discharge
        RIV=[iPer*uDitch LRC_ditch h_ditch CIN ZDitch ];
        WEL=[iPer*uSeep  LRC_seep  QSeep];
        continue
    end
    
    if MONTH(iPer)==MONTH(iPer-1), % use previous
        DRN=[DRN; -iPer, ones(1,5)];
        RIV=[RIV; -iPer, ones(1,6)];
    else
        DRN=[DRN;  iPer*uDitch LRC_ditch h_ditch CEX]; % same in as first period
        RIV=[RIV;  iPer*uDitch LRC_ditch h_ditch CIN ZDitch]; % same in as first period
    end
    WEL=[WEL; -iPer ones(1,4)]; % same as in first period (one value QSeep)
end

fprintf('Done in%.3f seconds.\n',toc);

%% Simulation using analytical solution with constante layer thickness and prescirbed flux

fprintf('And now let''s do it analytically ...\n');
tic

% Surface runoff is included in the DRN(IDRN) in the Budget file
% Only the water in the ditch is ignored when its level jumps
% this can be include as needed by jump times ditcharea. The rest is
% included in the RIV(IDitch) and DRN(IDitch) ouputs
% The model still works with constant aquifer thickness, to avoid rewetting troubles
% with very thin cover layers. Can be set to invlude varying thickness by
% switching on LAYCON in the workbook. Do this only of the cover layer is
% thick so it never falls dry.

Dt=diff(tne(:,1));

%% T=w^2 * sy / kD), where w is between half width of ditch and center of
%  parcel.

T  =(([P.w]-[P.wd]/2).^2.*[P.MU]./([P.hk1].*[P.D1]))';
TMU=T/3./[P.MU]';

if MONTH(1)>=4 && MONTH(1)<=9, h_ditch=[P.ZP]'; else h_ditch=[P.WP]'; end

s     =zeros(length(P),size(tne,1));  % head change due to recharge variation
h     =zeros(size(s)); h(:,1)=h_ditch;
runoff=zeros(length(P),length(tne(:,1)));

for it=1:length(Dt);
    
    %% Head due to varying ditch level alone
    if MONTH(it+1)~=MONTH(it)
        if MONTH(it+1)>=4 && MONTH(it+1)<=9, h_ditch=[P.ZP]'; else h_ditch=[P.WP]'; end
    end    
    h(:,it+1)=h(:,it).*exp(-(pi^2/4)*Dt(it)./T)+h_ditch.*(1-exp(-(pi^2/4)*Dt(it)./T));

    %% Head change due to varying recharge and seepage alone
    s(:,it+1)=s(:,it).*exp(-Dt(it)./(T/3)) + TMU.*(RECH(it)+[P.q]').*(1-exp(-Dt(it)./(T/3)));
    %s(:,it+1)=s(:,it).*exp(-Dt(it)./(T/3)) + TMU.*(RECH(it)+0).*(1-exp(-Dt(it)./(T/3)));
    
    %% Average head in cross section    
    I=find(s(:,it+1)+h(:,it+1)>[P.AHN]');
    
    if ~isempty(I),
        runoff(I,i)=(s(I,it+1)-[P(I).AHN]').*[P(I).MU]';
        s(I,it+1)=[P(I).AHN]'-h(I,it+1);
    end

    fprintf('.'); if rem(it,100)==0, fprintf('\n'); end
end

% superimpose
hanalyt=h+s;

fprintf('\nDone in %.3f seconds\n',toc);


% %% Compute GXG for the analytical simulation: VERPLAATST NAAR MF_ANALYZE_JOS ONDER GXG NUMERIEK!!
% 
% [GLGanalytic,GVGanalytic,GHGanalytic]=getGXG_jos(hanalyt,tne(:,1),0);
% 
% for i=1:length(P)
%     P(i).GHGanalytic=GHGanalytic(i);
%     P(i).GVGanalytic=GVGanalytic(i);
%     P(i).GLGanalytic=GLGanalytic(i);
% end

fprintf('Saving .... ');
save underneath P xGr yGr zGr tne s IDitch IDRN ISeep iDRN iDITCH1 iDITCH2 iWVP2 IBOUND_lay1 IBOUND_lay2 hanalyt IB1 IB2
fprintf('\nDone !\n');
fprintf('Now generate MODFLOW input files.\n');
fprintf('Total model preparation time = %.3f seconds\n',toc(tstart));
